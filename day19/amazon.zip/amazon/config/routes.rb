Rails.application.routes.draw do
  root "products#index"
  #
  get "/products/new" => "products#new", as: :new_product
  post "/products" => "products#create", as: :products

  get "/products/:id" => "products#show", as: :product
  get "/products" => "products#index"

  # resources :products
end
